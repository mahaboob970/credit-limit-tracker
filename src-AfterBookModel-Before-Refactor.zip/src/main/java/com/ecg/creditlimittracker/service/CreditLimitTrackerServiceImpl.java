package com.ecg.creditlimittracker.service;


import com.ecg.creditlimittracker.model.BookModel;
import com.ecg.creditlimittracker.model.ConflictBaseModel;
import com.ecg.creditlimittracker.model.ConflictModel;
import com.ecg.creditlimittracker.model.CreditLimitModel;
import com.ecg.creditlimittracker.util.Constants;
import com.ecg.creditlimittracker.util.strategy.FileReadingStrategy;
import com.ecg.creditlimittracker.util.strategy.GenericFileReader;
import com.ecg.creditlimittracker.util.strategy.StrategyFactory;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Stream;

@Service
public class CreditLimitTrackerServiceImpl implements CreditLimitTrackerService {

    SimpleDateFormat csvDateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
    SimpleDateFormat prnDateFormat = new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH);


    @Override
    public Map<String, CreditLimitModel> readCsvFile(String pathName) {

        // File Reader look into it; large file ; sequential read heavy ; 10 million record read;
        List<CreditLimitModel> beans = new ArrayList<>();
        Map<String, CreditLimitModel> map = new HashMap<>();
        try (CSVReader reader = new CSVReaderBuilder(new FileReader(pathName)).withSkipLines(1).build()) {
            String[] lineInArray;

            while ((lineInArray = reader.readNext()) != null) {
                Arrays.stream(lineInArray).forEach(x -> System.out.print(x + " : "));
                CreditLimitModel bean = new CreditLimitModel();
                for (int i = 0; i < lineInArray.length; i++) {
                    bean.setName(lineInArray[0]);
                    bean.setAddress(lineInArray[1]);
                    bean.setPostcode(lineInArray[2]);
                    bean.setPhoneNumber(lineInArray[3]);
                    bean.setCreditLimit(Double.valueOf(lineInArray[4]));
                    bean.setDob(csvDateFormat.parse(lineInArray[5]));
                    map.put(bean.getPhoneNumber(), bean);
                }
                beans.add(bean);
            }

            System.out.println("SIZE: " + beans.size());
            beans.forEach(System.out::println);

//            List<CsvModel> beans = new CsvToBeanBuilder(new FileReader("src/main/resources/Workbook2.csv"))
//                    .withType(CsvModel.class)
//                    .build()
//                    .parse();


//            System.out.println("READERS: ");
//            this.readingFiles();


        } catch (Exception e) {
            System.out.println("READING ERROR : " + e);
        }
        return map;

    }


//    public List<CsvModel> beanBuilderExample(Path path, Class clazz) throws Exception {
//        CsvTransfer csvTransfer = new CsvTransfer();
//        ColumnPositionMappingStrategy ms = new ColumnPositionMappingStrategy();
//        ms.setType(clazz);
//
//        Reader reader = Files.newBufferedReader(path);
//        CsvToBean cb = new CsvToBeanBuilder(reader)
//                .withType(clazz)
//                .withMappingStrategy(ms)
//                .build();
//
//        csvTransfer.setCsvList(cb.parse());
//        reader.close();
//        return csvTransfer.getCsvList();
//    }

//    public void readingFiles() throws Exception {
//        Path path = Paths.get(ClassLoader.getSystemResource("Workbook2.csv").toURI());
//        List<CsvModel> customers = new ArrayList();
//        customers = readCsvToBeanList(path, CsvModel.class, customers);
//        for (CsvModel c : customers) {
//            System.out.println(c.getName()+ " - " + c.getCreditLimit());
//        }
//    }
//
//    private <T> List<T> readCsvToBeanList(Path path, Class clazz, List<T> list) throws Exception {
//        HeaderColumnNameMappingStrategy ms = new HeaderColumnNameMappingStrategy();
//        ms.setType(clazz);
//
//        try (Reader reader = Files.newBufferedReader(path)) {
//            CsvToBean cb = new CsvToBeanBuilder(reader)
//                    .withType(clazz)
//                    .withMappingStrategy(ms)
//                    .build();
//
//            list = cb.parse();
//        }
//        return list;
//    }
//

    @Override
    public Map<String, CreditLimitModel> readPrnFile(String pathName) {

        BufferedReader br;
        List<CreditLimitModel> beans = new ArrayList<>();
        Map<String, CreditLimitModel> map = new HashMap<>();

        try {
            br = new BufferedReader(new InputStreamReader(new FileInputStream(pathName), StandardCharsets.ISO_8859_1));
            String line;

            int count = 0;
            while ((line = br.readLine()) != null) {
                if (count == 0) {
                    count += 1;
                    continue;
                }
                System.out.println(line);
                System.out.println("line");
//                Arrays.stream(line.split("\t")).forEach(x->list.add(x));

                CreditLimitModel bean = new CreditLimitModel();
                bean.setName(line.substring(0, 16).trim());
                bean.setAddress(line.substring(16, 38).trim());
                bean.setPostcode(line.substring(38, 47).trim());
                bean.setPhoneNumber(line.substring(47, 62).trim());
                bean.setCreditLimit((Double.parseDouble(line.substring(62, 74).trim())) / 100);


                bean.setDob(prnDateFormat.parse(line.substring(74).trim()));
                beans.add(bean);
                map.put(bean.getPhoneNumber(), bean);

            }
            System.out.println("SIZE: " + beans.size());
            beans.forEach(System.out::println);

        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
        return map;
    }


    @Override
    public void processData() {
        // TODO : Read directory and process files if files are different use condition
        // TODO: Split the read and process
        List<CreditLimitModel> result = new ArrayList<>();

        final Map<String, CreditLimitModel>[] csvOriginalMap = new Map[]{new HashMap<>()};
        final Map<String, CreditLimitModel>[] prnOriginalMap = new Map[]{new HashMap<>()};

        try {

            Files.walk(Paths.get(Constants.DIRECTORY_PATH)).filter(Files::isRegularFile).forEach(x ->
                    {
                        System.out.println(x);
                        if (x.toString().endsWith(".csv")) {
                            csvOriginalMap[0] = (readCsvFile(x.toString())); // TODO: Try for Path
                        } else if (x.toString().endsWith(".prn")) {
                            prnOriginalMap[0] = (readPrnFile(x.toString()));
                        }
                    }
            );
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Map: " + prnOriginalMap[0].size());

        // TODO: check on parallellStream
        prnOriginalMap[0].entrySet().parallelStream().forEach(x -> {
            if (csvOriginalMap[0].get(x.getKey()) != null && (csvOriginalMap[0].get(x.getKey()).getCreditLimit().doubleValue() != x.getValue().getCreditLimit().doubleValue())) {
                result.add(x.getValue());
            }

        });

        System.out.println("RESULT : ");
        result.forEach(System.out::println);


//        Map<String, CreditLimitModel> csvOriginalMap = this.readCsvFile();
//        Map<String, CreditLimitModel> prnOriginalMap = this.readPrnFile();


//        }
//        List<LoanersCreditLimitConflict> result = new CopyOnWriteArrayList<>();
//        for( int i = 0; i < workbooks.size() - 1; i++) {
//            Workbook workbook = workbooks.get(i);
//            for(int j = i + 1; j < workbooks.size(); j++){
//                Workbook anotherWorkbook = workbooks.get(j);
//                workbook.getLoaners().parallelStream().forEach( l -> anotherWorkbook.findLoaner(l)
//                        .filter(anotherL -> !l.hasEqualCreditLimit(anotherL))
//                        .ifPresent( anotherL -> result.add(new LoanersCreditLimitConflict(l, anotherL))));
//            }
//        }
//        return result;

    }


    // TODO: Add in interface
    public Map<String, Map<String, CreditLimitModel>> readAll() {

        final Map<String, CreditLimitModel>[] csvOriginalMap = new Map[]{new HashMap<>()};
        final Map<String, CreditLimitModel>[] prnOriginalMap = new Map[]{new HashMap<>()};


        // Filename, <phone-number,Records>
        final Map<String, Map<String, CreditLimitModel>> filesMap = new HashMap<>();


        try (Stream<Path> stream = Files.walk(Path.of(Constants.DIRECTORY_PATH))) {
            stream.filter(Files::isRegularFile).forEach(x ->
            {
                System.out.println(x);
                if (x.toString().endsWith(".csv")) {
                    FileReadingStrategy fileReadingStrategy = new StrategyFactory().createFileReadingStrategy(Constants.FileType.CSV);
                    filesMap.put(x.getFileName().toString(), new GenericFileReader(fileReadingStrategy, x.toString()).getContentMap());
                    // =(readCsvFile(x.toString())); // TODO: Try for Path
                } else if (x.toString().endsWith(".prn")) {
                    FileReadingStrategy fileReadingStrategy = new StrategyFactory().createFileReadingStrategy(Constants.FileType.PRN);
                    filesMap.put(x.getFileName().toString(), new GenericFileReader(fileReadingStrategy, x.toString()).getContentMap());
//                        prnOriginalMap[0] =(readPrnFile(x.toString()));
                }
            });

        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Map: " + prnOriginalMap[0].size());

        return filesMap;

    }


    // TODO: Add in interface
    public void processAll() {
        List<CreditLimitModel> result = new ArrayList<>();

        final Map<String, Map<String, CreditLimitModel>> filesMap = this.readAll();
//        final Collection<Map<String, CreditLimitModel>> recordMap = filesMap.values();

        Map<String,List<ConflictModel>> conflictModelList =new HashMap<>();

        Map<String, Map<String, List<String>>> m = new HashMap<String, Map<String, List<String>>>();

        for (String mainFile : filesMap.keySet()) {
            Map<String, CreditLimitModel> recordLevelMap = filesMap.get(mainFile);

            for (String nextFile : filesMap.keySet()) {
                Map<String, CreditLimitModel> nextLevelMap = filesMap.get(nextFile);
                if (!nextFile.equals(mainFile)) {
                    for (String nextLevelMapKey : nextLevelMap.keySet()) {
                        CreditLimitModel nextLevelModel=nextLevelMap.get(nextLevelMapKey);
                        if (recordLevelMap.get(nextLevelMapKey).getCreditLimit().doubleValue() != nextLevelModel.getCreditLimit().doubleValue()) {
                            result.add(nextLevelModel);
                            ConflictModel model =new ConflictModel();
//                            model.setAddress();

                        }

                    }

                }
            }


        }


//        for (String fileName : filesMap.keySet()) {
//            Map<String, CreditLimitModel> recordLevelMap = filesMap.get(fileName); // file name get;
//
//            for (String k1 : recordLevelMap.keySet()) {
//                CreditLimitModel nextModel = recordLevelMap.get(k1);
//                if (recordLevelMap.get(k1) != null && nextModel != null) {
////                    if(){
////
////                    }else
//                        if(recordLevelMap.get(k1).getCreditLimit().doubleValue() != record.getCreditLimit().doubleValue()){
//
//                    }
//                }
//
//
//            }
//        }

//        filesMap.forEach((file, records) -> {
//            Map<String, CreditLimitModel> firstMap = filesMap.get(file);
//            recordMap.forEach((ph, record) -> {
////                    if() TODO: CHeck file name inside the CreditLimit Model
//                if (firstMap.get(ph) != null && (firstMap.get(ph).getCreditLimit().doubleValue() != record.getCreditLimit().doubleValue())) {
//                    result.add(record);
//                }
//            });
//        });

//        filesMap.values().stream().forEach(x -> {
//            if (csvOriginalMap[0].get(x.getKey()) != null && (csvOriginalMap[0].get(x.getKey()).getCreditLimit().doubleValue() != x.getValue().getCreditLimit().doubleValue())) {
//                result.add(x.getValue());
//            }
//        });

        System.out.println("RESULT : ");
        result.forEach(System.out::println);

    }



    // ---------- BOOK MODEL-----------
    public List<BookModel> readAllBooks() {

        // Filename, <phone-number,Records>
        final Map<String, Map<String, CreditLimitModel>> filesMap = new HashMap<>();
        List<BookModel> bookModelList  = new ArrayList<>();

        try (Stream<Path> stream = Files.walk(Path.of(Constants.DIRECTORY_PATH))) {
            stream.filter(Files::isRegularFile).forEach(x ->
            {
                System.out.println(x);
                if (x.toString().endsWith(".csv")) {
                    FileReadingStrategy fileReadingStrategy = new StrategyFactory().createFileReadingStrategy(Constants.FileType.CSV);
//                    filesMap.put(x.getFileName().toString(), new GenericFileReader(fileReadingStrategy, x.toString()).getContentMap());
                    BookModel bookModel=new BookModel(x.getFileName().toString(),new GenericFileReader(fileReadingStrategy, x.toString()).getContentMap(),null);
                    bookModelList.add(bookModel);
                    // =(readCsvFile(x.toString())); // TODO: Try for Path
                } else if (x.toString().endsWith(".prn")) {
                    FileReadingStrategy fileReadingStrategy = new StrategyFactory().createFileReadingStrategy(Constants.FileType.PRN);
//                    filesMap.put(x.getFileName().toString(), new GenericFileReader(fileReadingStrategy, x.toString()).getContentMap());
//                        prnOriginalMap[0] =(readPrnFile(x.toString()));
                    BookModel bookModel=new BookModel(x.getFileName().toString(),new GenericFileReader(fileReadingStrategy, x.toString()).getContentMap(),null);
                    bookModelList.add(bookModel);
                }
            });

        } catch (IOException e) {
            e.printStackTrace();
        }


        return bookModelList;

    }

    // TODO: Add in interface
    public void processAllBooks() {

        List<BookModel> bookModelList = this.readAllBooks();

        Map<String, List<ConflictBaseModel>> conflictModelMap = new HashMap<>();

        bookModelList.stream().forEach(firstBookModel -> {
            Map<String, CreditLimitModel> recordLevelMap = firstBookModel.getRecordsMap();
            List<ConflictBaseModel> conflictBaseModelList = new ArrayList<>();
            bookModelList.stream().forEach(secondBookModel -> {
                Map<String, CreditLimitModel> nextLevelMap = secondBookModel.getRecordsMap();
                if (!firstBookModel.getFileName().equals(secondBookModel.getFileName())) {
                    for (String nextLevelMapKey : nextLevelMap.keySet()) {
                        CreditLimitModel nextLevelModel = nextLevelMap.get(nextLevelMapKey);
                        if (recordLevelMap.get(nextLevelMapKey).getCreditLimit().doubleValue() != nextLevelModel.getCreditLimit().doubleValue()) {
                            conflictBaseModelList.add(new ConflictBaseModel(secondBookModel.getFileName(),nextLevelModel));

                        }

                    }
                }
            });
            firstBookModel.setConflictBaseModelList(conflictBaseModelList);
        });

        System.out.println(bookModelList);


    }




}
