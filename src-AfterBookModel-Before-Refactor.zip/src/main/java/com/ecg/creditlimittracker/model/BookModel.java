package com.ecg.creditlimittracker.model;

import java.util.List;
import java.util.Map;

public class BookModel {

    private Map<String,CreditLimitModel> recordsMap; // phone number, model
    private List<ConflictBaseModel> conflictBaseModelList;
    private String fileName;


    public BookModel(String fileName, Map<String, CreditLimitModel> recordsMap, List<ConflictBaseModel>  conflictBaseModelList) {
        this.fileName = fileName;
        this.recordsMap = recordsMap;
        this.conflictBaseModelList = conflictBaseModelList;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Map<String, CreditLimitModel> getRecordsMap() {
        return recordsMap;
    }

    public void setRecordsMap(Map<String, CreditLimitModel> recordsMap) {
        this.recordsMap = recordsMap;
    }

    public List<ConflictBaseModel> getConflictBaseModelList() {
        return conflictBaseModelList;
    }

    public void setConflictBaseModelList(List<ConflictBaseModel> conflictBaseModelList) {
        this.conflictBaseModelList = conflictBaseModelList;
    }
}
