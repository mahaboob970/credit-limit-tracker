package com.ecg.creditlimittracker.model;

import com.opencsv.bean.CsvBindByName;

import java.util.Date;

public class CsvModel {

    @CsvBindByName(column = "Name")
    private String name;
    @CsvBindByName(column = "Address")
    private String address;
    @CsvBindByName(column = "Postcode")
    private String postcode;
    @CsvBindByName(column = "Phone")
    private String phoneNumber;
    @CsvBindByName(column = "Credit Limit")
    private Double creditLimit;
    @CsvBindByName(column = "Birthday")
    private Date dob;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Double getCreditLimit() {
        return creditLimit;
    }

    public void setCreditLimit(Double creditLimit) {
        this.creditLimit = creditLimit;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    @Override
    public String toString() {
        return "CsvModel{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", postcode='" + postcode + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", creditLimit=" + creditLimit +
                ", dob=" + dob +
                '}';
    }
}
