package com.ecg.creditlimittracker.model;

import java.util.Date;

public class CreditLimitModel extends BaseModel{
    private Double creditLimit;

    public Double getCreditLimit() {
        return creditLimit;
    }

    public void setCreditLimit(Double creditLimit) {
        this.creditLimit = creditLimit;
    }

    @Override
    public String toString() {
        return "CreditLimitModel{" +
                "creditLimit=" + creditLimit +
                '}' + super.toString();
    }
}
