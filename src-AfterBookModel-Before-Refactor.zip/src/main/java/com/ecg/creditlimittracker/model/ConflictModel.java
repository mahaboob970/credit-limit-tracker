package com.ecg.creditlimittracker.model;

import java.util.List;

public class ConflictModel extends BaseModel{

    private List<ConflictBaseModel> conflicts;

    public List<ConflictBaseModel> getConflicts() {
        return conflicts;
    }

    public void setConflicts(List<ConflictBaseModel> conflicts) {
        this.conflicts = conflicts;
    }

    @Override
    public String toString() {
        return super.toString() + " ConflictModel{" +
                "conflicts=" + conflicts +
                '}';
    }
}
