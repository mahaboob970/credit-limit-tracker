package com.ecg.creditlimittracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditLimitTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
