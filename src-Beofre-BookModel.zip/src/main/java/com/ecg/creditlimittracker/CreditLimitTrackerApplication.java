package com.ecg.creditlimittracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreditLimitTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditLimitTrackerApplication.class, args);
	}

}
