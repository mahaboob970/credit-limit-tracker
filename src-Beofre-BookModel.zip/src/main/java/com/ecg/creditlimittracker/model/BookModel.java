package com.ecg.creditlimittracker.model;

import com.ecg.creditlimittracker.util.Constants;

import java.util.Map;

public class BookModel {

    private Constants.FileType fileType;
    private Map<String,CreditLimitModel> recordsMap;
    private Map<String,CreditLimitModel>  conflictsMap;

    public Constants.FileType getFileType() {
        return fileType;
    }

    public void setFileType(Constants.FileType fileType) {
        this.fileType = fileType;
    }

    public Map<String, CreditLimitModel> getRecordsMap() {
        return recordsMap;
    }

    public void setRecordsMap(Map<String, CreditLimitModel> recordsMap) {
        this.recordsMap = recordsMap;
    }

    public Map<String, CreditLimitModel> getConflictsMap() {
        return conflictsMap;
    }

    public void setConflictsMap(Map<String, CreditLimitModel> conflictsMap) {
        this.conflictsMap = conflictsMap;
    }
}
