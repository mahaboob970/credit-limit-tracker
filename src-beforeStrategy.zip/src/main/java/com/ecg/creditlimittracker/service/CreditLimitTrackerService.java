package com.ecg.creditlimittracker.service;

import com.ecg.creditlimittracker.model.CreditLimitModel;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public interface CreditLimitTrackerService {

    public Map<String,CreditLimitModel> readCsvFile(String pathName);

    public Map<String,CreditLimitModel> readPrnFile(String pathName);

    public void processData();
}
